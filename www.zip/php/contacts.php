<?php

require __DIR__ . '/config.php';
ini_set('memory_limit', '512M');
set_time_limit(60);
ini_set('log_errors', 1);
ini_set('display_errors', 1);
error_reporting(E_ALL);

function send_to_socket($message) {
    $socketPath = '/tmp/qt_wayland_ipc.socket';

    if (!file_exists($socketPath)) {
        error_log("Socket file not found: $socketPath");
        return false;
    }

    $socket = @socket_create(AF_UNIX, SOCK_STREAM, 0);
    if ($socket === false) {
        error_log("Socket creation failed: " . socket_strerror(socket_last_error()));
        return false;
    }

    if (!@socket_connect($socket, $socketPath)) {
        error_log("Socket connection failed: " . socket_strerror(socket_last_error($socket)));
        socket_close($socket);
        return false;
    }

    $json = json_encode($message, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        error_log("Failed to encode message to JSON: " . json_last_error_msg());
        socket_close($socket);
        return false;
    }

    $payload = $json . "\n";
    $bytes = socket_write($socket, $payload, strlen($payload));
    socket_close($socket);

    if ($bytes === false || $bytes !== strlen($payload)) {
        error_log("Failed to write full message to socket");
        return false;
    }

    return true;
}

function send_and_receive_from_socket($message, $timeout = 3) {
    $socketPath = '/tmp/qt_wayland_ipc.socket';

    if (!file_exists($socketPath)) {
        error_log("Socket file not found: $socketPath");
        return false;
    }

    $socket = @socket_create(AF_UNIX, SOCK_STREAM, 0);
    if ($socket === false) {
        error_log("Socket creation failed: " . socket_strerror(socket_last_error()));
        return false;
    }

    if (!@socket_connect($socket, $socketPath)) {
        error_log("Socket connection failed: " . socket_strerror(socket_last_error($socket)));
        socket_close($socket);
        return false;
    }

    $json = json_encode($message, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        error_log("Failed to encode message to JSON: " . json_last_error_msg());
        socket_close($socket);
        return false;
    }

    $payload = $json . "\n";
    $bytes = @socket_write($socket, $payload, strlen($payload));
    if ($bytes === false || $bytes !== strlen($payload)) {
        error_log("Failed to write full message to socket");
        socket_close($socket);
        return false;
    }

    $response = '';
    @socket_set_nonblock($socket);
    $start = microtime(true);
    
    while (true) {
        $buf = @socket_read($socket, 4096, PHP_BINARY_READ);
        if ($buf === false) {
            $err = socket_last_error($socket);
            if ($err == SOCKET_EWOULDBLOCK || $err == SOCKET_EAGAIN) {
                if (microtime(true) - $start > $timeout) {
                    break;
                }
                usleep(10000);
                continue;
            }
            break;
        }
        if ($buf === "") {
            break;
        }
        $response .= $buf;
        if (strpos($response, "\n") !== false) {
            break; 
        }
    }
    
    @socket_close($socket);
    return trim($response);
}

function clean_field($value) {
    $value = trim($value);
    $value = strip_tags($value);
    return preg_replace('/[^\p{L}\p{N}\s@._:-]/u', '', $value);
}

function get_log_finish() {
    $log_file = '/opt/cumanphone/var/log/cumanphone1.log';
    if (!file_exists($log_file)) {
        return "00:00:00 00:00:00";
    }

    $fp = fopen($log_file, 'r');
    if (!$fp) return "00:00:00 00:00:00";

    fseek($fp, 0, SEEK_END);
    $position = ftell($fp);
    $buffer = '';
    $lines = [];

    while ($position > 0 && count($lines) < 5000) {
        $position--;
        fseek($fp, $position);
        $char = fgetc($fp);
        if ($char === "\n") {
            if ($buffer !== '') {
                $lines[] = strrev($buffer);
                $buffer = '';
            }
        } else {
            $buffer .= $char;
        }
    }
    if ($buffer !== '') $lines[] = strrev($buffer);

    fclose($fp);

    foreach ($lines as $log) {
        if (strpos($log, 'Set import_last_sync_time_https to:') !== false) {
            if (preg_match('/"(\d{2}\.\d{2}\.\d{4} \d{2}:\d{2}:\d{2})"/', $log, $matches)) {
                return $matches[1];
            }
        }
        
        if (strpos($log, 'Set import_last_sync_time_udp to:') !== false) {
            if (preg_match('/"(\d{2}\.\d{2}\.\d{4} \d{2}:\d{2}:\d{2})"/', $log, $matches)) {
                return $matches[1];
            }
        }
    }
    
    foreach ($lines as $log) {
        if (preg_match('/^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})/', $log, $matches)) {
            $dt = DateTime::createFromFormat('Y-m-d H:i:s', $matches[1]);
            if ($dt) {
                return $dt->format('d.m.Y H:i:s');
            }
        }
    }
    
    return "00.00.0000 00:00:00";
}

function get_log_number() {
    $log_file = '/opt/cumanphone/var/log/cumanphone1.log';
    if (!file_exists($log_file)) {
        return 0;
    }

    $logs = @file($log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (!$logs) return 0;

    foreach (array_reverse($logs) as $log) {
        if (strpos($log, 'Total contacts:') !== false) {
            if (preg_match('/Total contacts:\s+(\d+)/', $log, $matches)) {
                return intval($matches[1]);
            }
        }
        if (strpos($log, 'Contacts count:') !== false) {
            if (preg_match('/Contacts count:\s+(\d+)/', $log, $matches)) {
                return intval($matches[1]);
            }
        }
        if (strpos($log, 'Loaded') !== false && strpos($log, 'contacts') !== false) {
            if (preg_match('/Loaded\s+(\d+)\s+contacts/', $log, $matches)) {
                return intval($matches[1]);
            }
        }
    }

    $db_file = '/.local/share/CumanPhone/friends.db';
    if (file_exists($db_file)) {
        $db = new SQLite3($db_file);
        $result = $db->querySingle('SELECT COUNT(*) as count FROM friends');
        if ($result) {
            return intval($result);
        }
    }

    return 0;
}

// НОВАЯ ФУНКЦИЯ: Проверка состояния синхронизации
function check_sync_in_progress() {
    $socketResponse = send_and_receive_from_socket([
        'type' => 'contacts',
        'command' => 'get_contacts_sync_status'
    ], 2);
    
    if ($socketResponse) {
        $decoded = json_decode($socketResponse, true);
        if (json_last_error() === JSON_ERROR_NONE && isset($decoded['contacts_sync'])) {
            return $decoded['contacts_sync']['sync_in_progress'] ?? false;
        }
    }
    
    return false;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $data = new stdClass();

    $data->last_update_time = get_log_finish();
    $data->contacts_count = get_log_number();
    $data->contacts = [];

    $db_file = '/.local/share/CumanPhone/friends.db';
    if (file_exists($db_file)) {
        $db = new SQLite3($db_file);
        $results = $db->query('SELECT * FROM friends LIMIT 15000');
        if ($results) {
            while ($row = $results->fetchArray(SQLITE3_ASSOC)) {
                $id = (int)$row['id'];
                $sip = clean_field($row['sip_uri']);
                $vCard = $row['vCard'];

                if (strpos($vCard, 'BEGIN:VCARD') !== false && strpos($vCard, 'END:VCARD') !== false) {
                    $data->contacts[] = [
                        'id' => $id,
                        'sip_uri' => $sip,
                        'vCard' => $vCard
                    ];
                }
            }
        }
    }

    $config = load_config();
    if (($config['ui']['import_remote_contacts_enabled'] ?? "0") === "1") {
        $data->status = "1";
        $data->update_interval = $config['ui']['import_interval_index'] ?? "0";

        if ($data->last_update_time !== "00.00.0000 00:00:00") {
            $data->last_update_display = "Обн.: " . $data->last_update_time;
        } else {
            $data->last_update_display = "Обн.: никогда";
        }

        if (($config['ui']['import_remote_protocol_name'] ?? "0") === "0") {
            $data->protocol = "0";
            $data->url = $config['ui']['import_from_server_url_address'] ?? "";
            $type_https = $config['ui']['web_import_contacts_mode'] ?? "";
            $data->type_https = ($type_https === "Add") ? "1" : "0";
        } else {
            $data->protocol = "1";
            $data->address_port = $config['ui']['import_from_server_ip_address_and_port'] ?? "";
            $data->filename = $config['ui']['import_from_server_file_name'] ?? "";
            $type_udp = $config['ui']['udp_import_contacts_mode'] ?? "";
            $data->type_udp = ($type_udp === "Add") ? "1" : "0";
        }

    } else {
        $data->status = "0";
        $data->last_update_display = "Обн.: отключено";
    }

    send_to_socket(json_encode([
        'type' => 'contacts',
        'event' => 'contacts_fetched',
        'contacts_count' => count($data->contacts),
        'last_update_time' => $data->last_update_time
    ]));

    header('Content-Type: application/json');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $response = new stdClass();
    $contents = file_get_contents('php://input');
    $data = json_decode($contents);

    if (isset($data->command)) {
        if ($data->command === "get_contacts_sync_status") {
            $socketResponse = send_and_receive_from_socket([
                'type' => 'contacts',
                'command' => 'get_contacts_sync_status'
            ]);

            header('Content-Type: application/json');

            if ($socketResponse === false) {
                echo json_encode([
                    'error' => 'No response from socket',
                    'contacts_sync' => null
                ]);
                exit;
            }

            $decoded = json_decode($socketResponse, true);
            if (json_last_error() !== JSON_ERROR_NONE || !isset($decoded['contacts_sync'])) {
                echo json_encode([
                    'error' => 'Invalid or missing contacts_sync data',
                    'raw' => $socketResponse
                ]);
                exit;
            }

            echo $socketResponse;
            exit;
        }

        if ($data->command === "delete") {
            // ПРОВЕРКА: Блокировка удаления во время синхронизации
            if (check_sync_in_progress()) {
                header('Content-Type: application/json');
                echo json_encode([
                    'ok' => false,
                    'error' => 'contacts_sync_in_progress',
                    'message' => 'Удаление контактов недоступно до завершения текущей синхронизации.'
                ]);
                exit;
            }
            
            $dbPath = '/.local/share/CumanPhone/friends.db';
            
            if (file_exists($dbPath)) {
                file_put_contents($dbPath, '');
            }

            $response->success = 1;

            send_to_socket([
                'type' => 'contacts',
                'event' => 'contacts_deleted'
            ]);

            echo json_encode($response);
            exit;
        }

        if ($data->command === "save") {
            // ПРОВЕРКА: Блокировка сохранения во время синхронизации
            if (check_sync_in_progress()) {
                header('Content-Type: application/json');
                echo json_encode([
                    'ok' => false,
                    'error' => 'contacts_sync_in_progress',
                    'message' => 'Настройки синхронизации недоступны до завершения текущей синхронизации.'
                ]);
                exit;
            }
            
            $response = new stdClass();

            $status = $data->status == "1" ? "1" : "0";
            $protocol = (string)($data->protocol ?? "");
            $url = (string)($data->url ?? "");
            $address_port = (string)($data->address_port ?? "");
            $filename = (string)($data->filename ?? "");
            $type_https = ($data->type_https == "1") ? "1" : "0";
            $type_udp = ($data->type_udp == "1") ? "1" : "0";
            $update_interval = isset($data->update_interval) ? (string)$data->update_interval : "10";

            $message = [
                'type' => 'contacts',
                'event' => 'contacts_updated',
                'config' => [
                    'status' => $status,
                    'protocol' => $protocol,
                    'url' => $url,
                    'address_port' => $address_port,
                    'filename' => $filename,
                    'type_https' => $status === "1" ? $type_https : "",
                    'type_udp' => $status === "1" ? $type_udp : "",
                    'update_interval' => $update_interval
                ]
            ];

            $response = new stdClass();
                if (send_to_socket($message)) {
                    $response->success = 1;
                    $response->message = "Конфигурация отправлена через сокет.";
                } else {
                    $response->success = 0;
                    $response->message = "Не удалось отправить конфигурацию через сокет.";
                }

                echo json_encode($response, JSON_UNESCAPED_UNICODE);
                exit;
        }
    }
}
?>